//Pixel Art Project
var submitButton = document.getElementById('submitButton');
var table = document.querySelector('table');
var colorPicker = document.getElementById('colorPicker');
var colorValue = colorPicker.value;
//Add event listener to change value of color.
colorPicker.addEventListener("change", function() {
    colorValue = colorPicker.value;
});
//Event listner for the submit button.
//prevent refresh with preventDefault on event.
//assign variable to height and width
//call makegrid function.
submitButton.addEventListener("click", function(e) {
    e.preventDefault();
    var height = document.getElementById("inputHeight").value;
    var width = document.getElementById("inputWidth").value;
    makeGrid(height, width);
})
// When size is submitted by the user, call makeGrid()
//When you create the grid, Resets the Grid by deleting each row in currentRows
function makeGrid(height, width) {
    var currentRows = table.querySelectorAll('tr');
    currentRows.forEach(function(row) {
        table.removeChild(row);
    })
    //created a for loop to create each row and collumn.
    for (i = 0; i < height; i++) {
        var row = document.createElement('tr');
        table.appendChild(row);
        for (j = 0; j < width; j++) {
            var col = document.createElement('td');
            row.appendChild(col);
        }
        //added event listener to change color of background of targeted td.
        table.addEventListener("click", function(e) {
            if (e.target.nodeName == 'TD') {
                e.target.style.background = colorValue;
            }
        })
    }
}
